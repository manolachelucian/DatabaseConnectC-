﻿using System.Data.SqlClient;
namespace ConnectToDataBase
{
   
    internal class Program
    {
        static void Main(string[] args)
        {
            SqlConnectionStringBuilder stringBuilder = new SqlConnectionStringBuilder();
            stringBuilder.UserID = "sa";
            stringBuilder.Password = "student";
            stringBuilder.InitialCatalog = "test";
            stringBuilder.DataSource = "PC953";
            stringBuilder.ConnectTimeout = 30;

            try
            {
                using (SqlConnection connection = new SqlConnection(stringBuilder.ConnectionString))
                {
                    connection.Open();
                    Console.WriteLine("Pripojeno");
                    string query = "select * from osoby";


                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        SqlDataReader dataReader = command.ExecuteReader();
                        while (dataReader.Read())
                        {
                            Console.WriteLine(dataReader[0].ToString()+" "+ dataReader[1].ToString()+" "+ dataReader[2].ToString());
                        }
                    }
            }

            }catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}