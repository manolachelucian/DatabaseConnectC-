﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConnectToDataBase
{
    public class Osoba
    {
        private int id;
        private string name;
        private string surname;
         
        public int ID { get { return id; } set { id = value; } }
        public string Name { get { return name; } set { name = value; } }
        public string Surname { get { return surname; } set { surname = value; } }

        public Osoba (int id ,string name, string surname)
        {
            this.id = id;
            this.name = name;
            this.surname = surname;
        }
        public Osoba(string name, string surname)
        {
            this.id = 0;
            this.name = name;
            this.surname = surname;
        }
    }
}
